package com.liuzeyu.aspect;

import org.apache.logging.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.*;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.util.Arrays;

/**
 * Created by Administrator on 2020/1/31.
 */
@Aspect        //进行切面操作
@Component   //开启组件扫描
public class LogAspect {

    private final org.slf4j.Logger logger = LoggerFactory.getLogger(this.getClass());

    /**
     *
     定义在com.liuzeyu包和所有子包里的所有类的任意方法的执行
     */
    @Pointcut("execution(* com.liuzeyu.web.*.*(..))")
    public void log(){

    }

    //doBefor()方法会在切面之前来执行
    @Before("log()")
    public void doBefor(JoinPoint joinPoint){
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpServletRequest  request = attributes.getRequest();
        String methodName = joinPoint.getSignature().getDeclaringTypeName() + "." + joinPoint.getSignature().getName();

        RequestLog requestLog = new RequestLog(
                request.getRequestURI().toString(),   //URL
                request.getRemoteAddr(),             //IP地址
                methodName,                         //方法名
                joinPoint.getArgs());              //参数
        logger.info("Request ---- {}",requestLog);
    }

    //doAfter()方法会在切面之后来执行
    @After("log()")
    public void doAfter(){
//        logger.info("------------doAfter -----------");
    }

    //doAfterReturn()方法会在切面之后返回时候来执行根据注解传递的参数result来捕获返回的内容
    @AfterReturning(returning = "result",pointcut = "log()")
    public void doAfterReturn(Object result){
        logger.info("Result :{}",result);
    }


    //定义内部类封装请求参数
    private class RequestLog{
        private String url;
        private String ip;
        private String classMethod;
        private Object[] args;

        public RequestLog(String url, String ip, String classMethod, Object[] args) {
            this.url = url;
            this.ip = ip;
            this.classMethod = classMethod;
            this.args = args;
        }

        @Override
        public String toString() {
            return "RequestLog{" +
                    "url='" + url + '\'' +
                    ", ip='" + ip + '\'' +
                    ", classMethod='" + classMethod + '\'' +
                    ", args=" + Arrays.toString(args) +
                    '}';
        }
    }

}
