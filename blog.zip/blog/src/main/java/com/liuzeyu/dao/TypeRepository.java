package com.liuzeyu.dao;

import com.liuzeyu.po.Type;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Created by Administrator on 2020/2/2.
 */

//<User,Long> 操作对象和主键类型
//@Component
public interface TypeRepository extends JpaRepository<Type,Long> {
    Type findByName(String name);

    //自定义语句查询
    @Query("select t from Type t")
    List<Type> findTop(Pageable pageable);
}
