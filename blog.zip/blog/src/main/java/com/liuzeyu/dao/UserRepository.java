package com.liuzeyu.dao;

import com.liuzeyu.po.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by Administrator on 2020/2/2.
 */

//<User,Long> 操作对象和主键类型
@Component
public interface UserRepository extends JpaRepository<User,Long> {
     User findByUsernameAndPassword( String username, String password);

     //查找用户
     @Query(value = "select * from t_user  where username=?1 and email=?2", nativeQuery = true)
     List<User> findByUsername(String username,String email);

     //修改密码
     @Transactional
     @Modifying
     @Query(value = "UPDATE t_user  set password=?1", nativeQuery = true)
     void updatePassword(String password);
}
