package com.liuzeyu.interceptor;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by Administrator on 2020/2/3.
 */

/**
 * 登录拦截器
 * 实现的功能：
 * 1、在/admin 界面不能访问/admin/blogs [安全起见]
 * 2、登入进去后,即进入/admin/login,这个时候就可以访问/admin/blogs
 *    因为此时共享一个session
 */
public class LoginInterceptor extends HandlerInterceptorAdapter {
    //在请求达到之前拦截
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

        if (request.getSession().getAttribute("user") == null)  //如果session中不包含user了
        {
            response.sendRedirect("/admin");   //重定向到登录页
            return false;
        }
        return true;
    }
}
