package com.liuzeyu.interceptor;


/**
 * Created by Administrator on 2020/2/3.
 */
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

/**
 * 管理拦截内容的配置器
 * 注：WebMvcConfigurerAdapter的替代使用
 * https://segmentfault.com/a/1190000018904390?utm_source=tag-newest
 */
@Configuration
public class WebConfig extends WebMvcConfigurerAdapter {

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(new LoginInterceptor()).
                addPathPatterns("/admin/**"). //添加拦截[为了博客的安全所设的一张网]
                excludePathPatterns("/admin").  //[放行]
                excludePathPatterns("/admin/login"); //[放行]
    }
}
