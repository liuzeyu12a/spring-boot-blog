package com.liuzeyu.po;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2020/2/1.
 */
@Entity    //与数据库表建立连接
@Table(name = "t_type")     //初始化表名
public class Type {

    @Id  //主键id
    @GeneratedValue
    private Long id;
    @NotBlank(message = "分类名称不能为空！")   //添加后端非空检验
    private String name;

    /**
     * 一个类型包含多个博客(多的一端维护少的一端)
     */
    @OneToMany(mappedBy = "type")
    private List<Blog> blogs = new ArrayList<>();

    public List<Blog> getBlogs() {
        return blogs;
    }

    public void setBlogs(List<Blog> blogs) {
        this.blogs = blogs;
    }

    @Override
    public String toString() {
        return "Type{" +
                "id=" + id +
                ", name='" + name + '\'' +
                '}';
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public Type() {
    }
}
