package com.liuzeyu.service;

import com.liuzeyu.po.Blog;
import com.liuzeyu.vo.BlogQuery;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Map;

/**
 * Created by Administrator on 2020/2/4.
 */
public interface BlogService {
    //获取博客
    Blog getBlog(Long id);
    //获取分页博客
    Page<Blog> listBlog(Pageable pageable,BlogQuery blog);

    Page<Blog> listBlog(Long id,Pageable pageable);

    Page<Blog> listBlog(Pageable pageable);

    //搜索博客
    Page<Blog> listBlog(String query,Pageable pageable);
    //保存博客
    Blog savaBlog(Blog blog);
    //更新博客
    Blog updateBlog(Long id,Blog blog);
    //删除博客
    void deleteBlog(Long id);

    List<Blog> listRecommedBlogTop(Integer size);

    Blog getAndConvert(Long id);

    //获取归档的博客列表
    Map<String,List<Blog>> achiveBlog();

    //计算博客数目
    Long blogCount();
}
