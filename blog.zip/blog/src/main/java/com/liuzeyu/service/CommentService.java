package com.liuzeyu.service;

import com.liuzeyu.po.Comment;

import java.util.List;

/**
 * Created by Administrator on 2020/2/10.
 */
public interface CommentService {

    List<Comment> listCommentByBlogId(Long blogId);

    Comment saveComment(Comment comment);
}
