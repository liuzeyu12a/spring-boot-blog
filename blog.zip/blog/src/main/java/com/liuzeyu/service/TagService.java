package com.liuzeyu.service;

import com.liuzeyu.po.Tag;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

/**
 * Created by Administrator on 2020/2/4.
 */
public interface TagService {

    //保存分类
    Tag savaTag(Tag tag);

    //获取分类
    Tag getTag(Long id);

    Tag getTagByName(String name);

    //显示分类
    Page<Tag> listTag(Pageable pageable);

    //更新分类
    Tag updateTag(Tag tag, Long id);

    //删除分类
    void deleteTag(Long id);

    //返回标签容器
    List<Tag> listTag();
    //返回标签容器
    List<Tag> listTag(String ids);

    List<Tag> listTagTop(Integer size);   //传到前台的index数据
}
