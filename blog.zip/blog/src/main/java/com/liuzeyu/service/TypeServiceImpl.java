package com.liuzeyu.service;

import com.liuzeyu.NotFoundException;
import com.liuzeyu.dao.TypeRepository;
import com.liuzeyu.po.Type;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by Administrator on 2020/2/2.
 */

/**
 * Service层
 */

@Service
public class TypeServiceImpl implements TypeService {

    @Autowired  //接口注入
    private TypeRepository typeRepository;

    @Transactional
    @Override
    public Type savaType(Type type) {

        return typeRepository.save(type);
    }

    @Transactional
    @Override
    public Type getType(Long id) {
        return typeRepository.findById(id).orElse(null);

    }

    @Override
    public Type getTypeByName(String name) {
        return typeRepository.findByName(name);
    }

    @Transactional
    @Override
    public Page<Type> listType(Pageable pageable) {
        return typeRepository.findAll(pageable);
    }

    @Transactional
    @Override
    public Type updateType(com.liuzeyu.po.Type type, Long id) {
        Type t = typeRepository.findById(id).orElse(null);
        if( t== null){
            throw new NotFoundException("不存在该类型");
        }
        BeanUtils.copyProperties(type,t);   //type copy to t
        return typeRepository.save(t);
    }

    @Transactional
    @Override
    public void deleteType(Long id) {
        typeRepository.deleteById(id);
    }

    @Override
    public List<Type> listType() {
        return typeRepository.findAll();
    }


    @Override
    public List<Type> listTypeTop(Integer size) {
        //定义排序规则
      Sort sort = Sort.by(Sort.Direction.DESC,"blogs.size");
      //为pageable 定义排序规则
        Pageable pageable =  PageRequest.of(0,size,sort);
        return typeRepository.findTop(pageable);
    }
}
