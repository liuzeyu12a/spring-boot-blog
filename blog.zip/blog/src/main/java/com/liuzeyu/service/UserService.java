package com.liuzeyu.service;

import com.liuzeyu.po.User;

import java.util.List;

/**
 * Created by Administrator on 2020/2/2.
 */
public interface UserService {

    User checkUser(String username, String password);

    void updatePassword(User user);
    List<User> findByUsername(String username,String email);
}
