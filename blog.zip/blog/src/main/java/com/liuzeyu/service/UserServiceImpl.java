package com.liuzeyu.service;

import com.liuzeyu.dao.UserRepository;
import com.liuzeyu.po.User;
import com.liuzeyu.until.MD5Utils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by Administrator on 2020/2/2.
 */


@Service
public class UserServiceImpl implements UserService {

    @Autowired  //接口注入
    public UserRepository userRepository;

    //检查用户密码是否正确
    @Override
    public User checkUser(String username, String password) {
        User user = userRepository.findByUsernameAndPassword(username, MD5Utils.code(password));
        return user;
    }

    @Override
    public void updatePassword(User user) {
        userRepository.updatePassword(user.getPassword());
    }


    //注册


    @Override
    public List<User> findByUsername(String username,String email) {
        return userRepository.findByUsername(username,email);
    }


}
