package com.liuzeyu.until;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Created by Administrator on 2020/2/3.
 */

public class MD5Utils {

    public static String code(String str){

//        MessageDigest 类为应用程序提供信息摘要算法的功能，如 MD5 或 SHA 算法。
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(str.getBytes());
            byte[] byteDigest = md.digest();
            int i;
            StringBuffer buf = new StringBuffer("");
            for(int offset = 0;offset < byteDigest.length;offset++){
                i = byteDigest[offset];
                i += 256;
                if(i < 16)
                    buf.append("0");
                buf.append(Integer.toHexString(i));
            }
            //32位加密
            return buf.toString();
            //16位加密
            //return buf.toString().substring(8,24);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static void main(String[] args) {
        System.out.println(MD5Utils.code("809080"));
    }
}
