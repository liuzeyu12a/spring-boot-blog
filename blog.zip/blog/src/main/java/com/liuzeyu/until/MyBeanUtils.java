package com.liuzeyu.until;

import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;

import java.beans.PropertyDescriptor;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2020/2/7.
 */
public class MyBeanUtils {


    /**
     * 获取所有属性值为空值的对象  ==== >数组[过滤空值]
     * @param source
     * @return
     */
    public static String[] getNullPropertyName(Object source){
        BeanWrapper beanWrapper = new BeanWrapperImpl(source);
        PropertyDescriptor []pds  = beanWrapper.getPropertyDescriptors();
        List<String> nullPropertyNames = new ArrayList<String>();

        for (PropertyDescriptor pd : pds) {
            String protertyName = pd.getName();
            if(beanWrapper.getPropertyValue(protertyName) == null){
                nullPropertyNames.add(protertyName);
            }
        }
        return nullPropertyNames.toArray(new String[nullPropertyNames.size()]);
    }
}
