package com.liuzeyu.vo;

/**
 * Created by Administrator on 2020/2/5.
 */
public class BlogQuery {

    private String title;
    private Long typeId;
    private boolean recommed;

    public BlogQuery() {
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Long getTypeId() {
        return typeId;
    }

    public void setTypeId(Long typeId) {
        this.typeId = typeId;
    }

    public boolean isRecommend() {
        return recommed;
    }

    public void setRecommend(boolean recommed) {
        this.recommed = recommed;
    }
}
