package com.liuzeyu.web;

import com.liuzeyu.service.BlogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * Created by Administrator on 2020/1/30.
 */
@Controller
public class ArchiveShowController {

    @Autowired
    private BlogService blogService;

    //显示归档页面
    @GetMapping("/archives")
    public String achives(Model model){
        model.addAttribute("archiveMap",blogService.achiveBlog());
        model.addAttribute("blogCount",blogService.blogCount());
        return "archives";
    }



}
