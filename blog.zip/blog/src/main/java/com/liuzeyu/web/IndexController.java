package com.liuzeyu.web;

import com.liuzeyu.service.BlogService;
import com.liuzeyu.service.TagService;
import com.liuzeyu.service.TypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * Created by Administrator on 2020/1/30.
 */
@Controller
public class IndexController {

    @Autowired
    private BlogService blogService;
    @Autowired
    private TypeService typeService;
    @Autowired
    private TagService tagService;

    @GetMapping("/")
    public String index(@PageableDefault(size = 4,sort = {"updateTime"},direction = Sort.Direction.DESC) Pageable pageable,
                        Model model){
        model.addAttribute("page",blogService.listBlog(pageable));
        model.addAttribute("types",typeService.listTypeTop(6));  //填充的分类
        model.addAttribute("tags",tagService.listTagTop(12));  //填充标签分类
        model.addAttribute("recommedBlogs",blogService.listRecommedBlogTop(8));  //填充推荐
        return "index";
    }


    @PostMapping("/search")
    public String search(@PageableDefault(size = 4,sort = {"updateTime"},direction = Sort.Direction.DESC) Pageable pageable,
                         Model model,
                         @RequestParam String query){
        //添加搜索结果分页
        model.addAttribute("page",blogService.listBlog("%"+query+"%",pageable));
        model.addAttribute("query",query);   //返回数据到搜索框
        return "search";
    }


    //通过id获取博客
    @GetMapping("/blog/{id}")
    public String blogs(@PathVariable  Long id, Model model){
        model.addAttribute("blog",blogService.getAndConvert(id));
        model.addAttribute("newblogs",blogService.listRecommedBlogTop(3));
        return "blog";
    }

    @GetMapping("/footer/newblog")
    public String newblogs(Model model){
        model.addAttribute("newblogs",blogService.listRecommedBlogTop(3));
        return "_fragments :: newblogList";
    }
}
