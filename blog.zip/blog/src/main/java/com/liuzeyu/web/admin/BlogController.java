package com.liuzeyu.web.admin;

import com.liuzeyu.po.Blog;
import com.liuzeyu.po.User;
import com.liuzeyu.service.BlogService;
import com.liuzeyu.service.TagService;
import com.liuzeyu.service.TypeService;
import com.liuzeyu.vo.BlogQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpSession;

/**
 * Created by Administrator on 2020/1/30.
 */
@Controller
@RequestMapping("/admin")
public class BlogController {

    @Autowired
    private BlogService blogService;
    @Autowired
    private TypeService typeService;
    @Autowired
    private TagService tagService;

    @GetMapping("/blogs")
    public String blogs(@PageableDefault(size = 2,sort = {"updateTime"},direction = Sort.Direction.DESC) Pageable pageable,
                        BlogQuery blog,
                        Model model){
        model.addAttribute("types",typeService.listType());   //在渲染界面时就进行分类的显示
        model.addAttribute("page",blogService.listBlog(pageable,blog));  //前端渲染
        model.addAttribute("newblogs",blogService.listRecommedBlogTop(3));
        return "admin/blogs";
    }

    //点击搜索，只渲染表格部分
    @PostMapping("/blogs/search")
    public String search(@PageableDefault(size = 2,sort = {"updateTime"},direction = Sort.Direction.DESC) Pageable pageable,
                         BlogQuery blog,
                        Model model){
        model.addAttribute("page",blogService.listBlog(pageable,blog));  //前端渲染
        return "admin/blogs :: blogList";
    }

    @GetMapping("/blogs/input")
    public String input(Model model){
        setTagAndType(model);
        model.addAttribute("newblogs",blogService.listRecommedBlogTop(3));
        model.addAttribute("blog",new Blog());
        return "admin/blogs-input";
    }
    public void setTagAndType(Model model){
        model.addAttribute("types",typeService.listType());  //初始化分类
        model.addAttribute("tags",tagService.listTag());  //初始化分类
    }

    @GetMapping("/blogs/{id}/input")
    public String eidtInput(@PathVariable Long id, Model model){
        setTagAndType(model);
        Blog blog = blogService.getBlog(id);
        blog.init();   //处理tagId 为一个字符串 并返回前端tagIds
        model.addAttribute("blog",blog);
        model.addAttribute("newblogs",blogService.listRecommedBlogTop(3));
        return "admin/blogs-input";
    }

    @PostMapping("/blogs")
    public String post(Blog blog, RedirectAttributes redirectAttributes,HttpSession session){
        blog.setUser((User) session.getAttribute("user"));
        blog.setType(typeService.getType(blog.getType().getId()));  //blog.getType().getId()前端返回typeId
        blog.setTags(tagService.listTag(blog.getTagIds()));   //获取tags

        Blog b ;
        if(blog.getId() == null){
            b = blogService.savaBlog(blog);
        }else{
            b = blogService.updateBlog(blog.getId(),blog);
        }

        if( b == null){
            redirectAttributes.addFlashAttribute("message","操作失败！");
        }else{
            redirectAttributes.addFlashAttribute("message","操作成功！");
        }
        return "redirect:/admin/blogs";
    }

    @GetMapping("/blogs/{id}/delete")
    //@PathVariable ：在返回的时候自动赋值
    public String delete(@PathVariable  Long id,RedirectAttributes redirectAttributes){
        blogService.deleteBlog(id);
        redirectAttributes.addFlashAttribute("message","删除成功");
        return "redirect:/admin/blogs";
    }


}
