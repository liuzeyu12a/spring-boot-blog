package com.liuzeyu.web.admin;

import com.liuzeyu.po.User;
import com.liuzeyu.service.BlogService;
import com.liuzeyu.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * Created by Administrator on 2020/2/2.
 */
@Controller
@RequestMapping("/admin")
public class LoginController {

    @Autowired
    private BlogService blogService;

    @Autowired
   private  UserService userService ;
    @GetMapping
    public String loginPage(){
        return "admin/login";
    }


// @RequestParam：将请求参数绑定到你控制器的方法参数上（是springmvc中接收普通参数的注解）
    @PostMapping("/login")  //Post提交参数后@RequestParam绑定到控制器上
    public String login(@RequestParam  String username,
                        @RequestParam  String password,
                        HttpSession session,
                        RedirectAttributes attributes){
        User user = userService.checkUser(username,password);  //检查用户名密码的正确性
        if(user != null){  //查询成功
            user.setPassword(null);   //密码为了安全起见不要返回到session中
            session.setAttribute("user",user);  //存入session
            return "admin/index";   //返回首页
        }else{
//            重定向之后在URL后面拼接参数并返回给前端界面
            attributes.addFlashAttribute("message","用户名和密码错误！");
            return "redirect:/admin";   //返回adminA
        }
    }

    //注销
    @GetMapping("/logout")
    public String logout(HttpSession session){
        session.removeAttribute("user");
        return "redirect:/admin";
    }


    @GetMapping("/footer/newblog")
    public String newblogs(Model model){
        model.addAttribute("newblogs",blogService.listRecommedBlogTop(3));
        return "admin/_fragments :: newblogList";
    }
}
