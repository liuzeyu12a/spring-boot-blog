package com.liuzeyu.web.admin;


import com.liuzeyu.po.User;
import com.liuzeyu.service.BlogService;
import com.liuzeyu.service.UserService;
import com.liuzeyu.until.MD5Utils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
//@RestController
public class RegisterController {


    @Autowired
    private BlogService blogService;

    @Autowired
    private UserService userService ;

    @RequestMapping("/registers")
    public String zhuce(){
        return "admin/register.html";
    }

    //注册功能
    @PostMapping("/register")
    public String register(@RequestParam("username") String username, @RequestParam("password")
            String password, @RequestParam("password2") String password2,@RequestParam("email") String email,
                           RedirectAttributes attributes,
                           HttpSession session){
        ModelAndView success = new ModelAndView();

        //两次密码不一样的判断条件
        if(!password.equals(password2)){
            success.setViewName("admin/register");
            attributes.addFlashAttribute("message","两次密码不一样！");
            return "redirect:/registers";   //返回adminA;
        }
        //判断是否取到用户，如果没有就保存在数据库中
        List<User> us=userService.findByUsername(username,email);
        if(us.size()!=0){
            //List<Login> register=loginService.save(username,password);
            User update=new User();
            String code = MD5Utils.code(password);  //md5加密
            update.setPassword(code);
            attributes.addFlashAttribute("message","密码修改成功,请使用新密码登录！");
            userService.updatePassword(update);
            return "redirect:/admin";
        }
        else {
            attributes.addFlashAttribute("message","该用户尚未注册或者邮箱不匹配输入错误！");
            return "redirect:/registers";   //返回adminA
        }

    }
}
