package com.liuzeyu.web.admin;


import com.liuzeyu.po.Type;
import com.liuzeyu.service.BlogService;
import com.liuzeyu.service.TypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.bind.BindResult;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;


/**
 * Created by Administrator on 2020/2/2.
 */
@Controller
@RequestMapping("/admin")
public class TypeController {
    @Autowired
    private BlogService blogService;
    @Autowired
    private TypeService typeService;

    @GetMapping("/types")  //PageableDefault分页的规范 默认五条 降序排列 按照主键id
    public String types(@PageableDefault(size = 5,sort = {"id"},direction = Sort.Direction.DESC)
                                Pageable pageable, Model model){
        model.addAttribute("page", typeService.listType(pageable));
        //page的数据见下方
        return "admin/types";
    }

    //跳转到types-input，model.addAttribute("type",new Type());为前台的type添加数据
    @GetMapping("/types/input")
    public String input(Model model){
        model.addAttribute("type",new Type());
        model.addAttribute("newblogs",blogService.listRecommedBlogTop(3));
        return "admin/types-input";
    }

    //点击编辑跳转到types-input.html
    @GetMapping("/types/{id}/input")
    public String editInput(@PathVariable Long id, Model model){
        model.addAttribute("type",typeService.getType(id));
        return "admin/types-input";
    }


    //接受types-input表单传过来的types
    @PostMapping("types")
    public String post(@Valid Type type,
                       BindingResult result,
                       RedirectAttributes redirectAttributes){
        Type type1 = typeService.getTypeByName(type.getName());
        if(type1 != null){   //找到重复的名称
        result.rejectValue("name","nameError","不能添加重复的分类！");
    }
        if(result.hasErrors()){
            return "admin/types-input";  //返回错误信息数据至前台
        }
        Type t = typeService.savaType(type);
        if(t == null){
            redirectAttributes.addFlashAttribute("message","新增失败！");
        }else{
            redirectAttributes.addFlashAttribute("message","新增成功！");
        }
        return "redirect:/admin/types";
    }

    //主要通过id来判断是不是新增的id，即是否是修改的
    @PostMapping("/types/{id}")
    public String editPost(@Valid Type type,
                       BindingResult result,
                       @PathVariable Long id,
                       RedirectAttributes redirectAttributes){
        Type type1 = typeService.getTypeByName(type.getName());
        if(type1 != null){   //找到重复的名称
            result.rejectValue("name","nameError","不能添加重复的分类！");
        }
        if(result.hasErrors()){
            return "admin/types-input";  //返回错误信息数据至前台
        }
        Type t = typeService.updateType(type,id);
        if(t == null){
            redirectAttributes.addFlashAttribute("message","更新失败！");
        }else{
            redirectAttributes.addFlashAttribute("message","更新成功！");
        }
        return "redirect:/admin/types";
    }


    //删除type
    @GetMapping("/types/{id}/delete")
    public String delete(@PathVariable Long id,
                         RedirectAttributes redirectAttributes){
        typeService.deleteType(id);
        redirectAttributes.addFlashAttribute("message","删除成功！");
        return "redirect:/admin/types";
    }
}
/**page数据：
         * {
         "content":[
         {"id":123,"title":"blog122","content":"this is blog content"},
         {"id":122,"title":"blog121","content":"this is blog content"},
         {"id":121,"title":"blog120","content":"this is blog content"},
         {"id":120,"title":"blog119","content":"this is blog content"},
         {"id":119,"title":"blog118","content":"this is blog content"},
         {"id":118,"title":"blog117","content":"this is blog content"},
         {"id":117,"title":"blog116","content":"this is blog content"},
         {"id":116,"title":"blog115","content":"this is blog content"},
         {"id":115,"title":"blog114","content":"this is blog content"},
         {"id":114,"title":"blog113","content":"this is blog content"},
         {"id":113,"title":"blog112","content":"this is blog content"},
         {"id":112,"title":"blog111","content":"this is blog content"},
         {"id":111,"title":"blog110","content":"this is blog content"},
         {"id":110,"title":"blog109","content":"this is blog content"},
         {"id":109,"title":"blog108","content":"this is blog content"}],
         "last":false,
         "totalPages":9,
         "totalElements":123,
         "size":15,
         "number":0,
         "first":true,
         "sort":[{
         "direction":"DESC",
         "property":"id",
         "ignoreCase":false,
         "nullHandling":"NATIVE",
         "ascending":false
         }],
         "numberOfElements":15
         }
 */
